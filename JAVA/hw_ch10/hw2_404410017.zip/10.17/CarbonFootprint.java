
public interface CarbonFootprint {
	double getCarbonFootprint();	//CarbonFootprint : kilograms per day
}
